    class week4_3 {
        public static void main(String[] args){
            System.out.println("manufacturer = Redmi");
            System.out.println("operating_system = Andriod");
            System.out.println("color = Blue");
            int cost = 34000;
            System.out.printf("cost = %d",cost);
        }
    }

